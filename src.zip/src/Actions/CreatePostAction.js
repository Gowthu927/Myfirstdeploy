import axios from 'axios';

const URL='http://reduxblog.herokuapp.com/api';
const KEY='?key=123';

export const CreatePostAction=()=>{

}
