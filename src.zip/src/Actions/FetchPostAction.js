import axios from 'axios';

const URL='http://reduxblog.herokuapp.com/api';
const KEY='?key=123';

export const FetchPostAction=()=> async dispatch=>{
    const res=await axios.get(`${URL}/posts${KEY}`);
    dispatch ({type:'FETCH_POST',payload:res} );
}
