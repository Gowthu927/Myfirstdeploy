import React from 'react';
import {Link} from 'react-router-dom';
import {Field,reduxForm} from 'redux-form';
import {CreatePostAction} from '../Actions/CreatePostAction';
import {connect} from 'react-redux';


class NewPost extends React.Component{

    textHelper=(field)=>{
        return(
            <div>
                <h3>{field.label}</h3>
                <input type='text' {...field.input} />
                {field.meta.touched && field.meta.error}
            </div>
        );
    }
    checked=(val)=>{
        this.props.CreatePostAction(val);
    }

    render(){
        const {handleSubmit}=this.props;
        return(
            <div>
                <form onSubmit={handleSubmit(this.checked)} >
                    <Field label='Title' name='title' component={this.textHelper} />
                    <Field label='Category' name='category' component={this.textHelper} />
                    <Field label='Details' name='details' component={this.textHelper} />
                    <button>Submit</button>
                </form>
                <Link to='/'><button>Navu</button></Link>
            </div>
            
        );
    }
}
const validate=(field)=>{
    let error={};
    if(!field.title){
        error.title='Enter title';
    }
    if(!field.category){
        error.category='Enter category';
    }
    if(!field.details){
        error.details='Enter details';
    }
    return error;
}

export default reduxForm({
    validate,
    form:'NewUserForm'
})(connect(null,{CreatePostAction})(NewPost));