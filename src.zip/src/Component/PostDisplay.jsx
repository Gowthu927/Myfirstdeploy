import React from 'react';
import {Link} from 'react-router-dom';
import {connect} from 'react-redux';
import {FetchPostAction} from '../Actions/FetchPostAction';

class PostDisplay extends React.Component{
    componentDidMount=()=>{
        this.props.FetchPostAction();
    }
    Helper=()=>{
        
        let items = Object.keys(this.props.post);
        console.log(JSON.stringify(items));
        items.map(data=>{
            
            return(
                <div>
                    {data.title}<hr></hr>
                    {data.content}
                </div>
            );
        })
        // forEach (this.props.post){
        //     return (
        //         <div>
        //             <p>{this.props.post[key].title}</p><hr></hr>
        //             <p>{this.props.post[key].content}</p>
        //         </div>
        //     )
        // }
    }
    render(){
        return(
            <div>
                <p>Post display</p>
                <div>
                    {this.Helper()}
                </div>
                <Link to='/posts/new'><button>Navu</button></Link>
            </div>
            
        );
    }
}
const mapStatetoProps=(state)=>{
    return { post: state.post}
}

export default connect(mapStatetoProps,{FetchPostAction})(PostDisplay);