export default (state={},action)=>{
    switch (action.type) {
        case 'FETCH_POST':
            let post={};
            action.payload.data.forEach(data=>{
                post[data.id]=data;
            })
            return post;
    
        default:
            return state;
    }
}