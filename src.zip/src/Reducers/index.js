import {combineReducers} from 'redux';
import FetchPostReducer from './FetchPostReducer';
import { reducer as formReducer } from 'redux-form';


export default combineReducers({
    post:FetchPostReducer,
    form:formReducer
});