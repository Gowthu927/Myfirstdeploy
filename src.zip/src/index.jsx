import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter,Route,Switch} from 'react-router-dom';
import {Provider} from 'react-redux';
import NewPost from './Component/NewPost';
import PostDisplay from './Component/PostDisplay';
import {createStore,applyMiddleware} from 'redux';
import reducers from './Reducers';
import thunk from 'redux-thunk';

const store=createStore(reducers,applyMiddleware(thunk));

ReactDOM.render(
    <Provider store={store}>
        <BrowserRouter>
            <Switch>
                <Route path='/' exact component={PostDisplay} />
                <Route path='/posts/new' component={NewPost} />
            </Switch>
        </BrowserRouter>
    </Provider>,
    document.getElementById('root')
);
